/**
 * Marc Feldman
 * Hugh Han
 * SeungHwan Lee
 * Matthew Cowen-Green
 *
 * EN.600.120 Intermediate Programming, Spring 2015
 * SkipBo: SkipBo.cpp
 */

#include "GameController.h"

int main() {

  GameController skipBo;
  skipBo.runGame();

  return 0;
	
}
